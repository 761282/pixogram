package com.social.pixogram.service;

import java.util.List;

import com.social.pixogram.model.Newsfeed;

public interface NewsfeedService {

	void save(Newsfeed newsFeed);

	List<Newsfeed> findAllByUserId(long userId);

}
