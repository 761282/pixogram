import { Component, OnInit } from '@angular/core';
import { Title }     from '@angular/platform-browser';
import { NewsfeedService } from 'src/services/newsfeed.service';

@Component({
  selector: 'app-news-feed',
  templateUrl: './news-feed.component.html',
  styleUrls: ['./news-feed.component.css']
})
export class NewsFeedComponent implements OnInit {

  constructor(private titleService: Title,private newsfeedService: NewsfeedService) {
    titleService.setTitle('Newsfeed!')
   }

   userId=localStorage.getItem("userId");
   newsfeed;
  ngOnInit() {
    this.getNewsFeed();
  }

  getNewsFeed(){
    this.newsfeedService.getNewsFeed(this.userId).subscribe(async res=>{
      this.newsfeed= await res;
      console.log(this.newsfeed);
    },err=>{
      console.log("err");
    });

    
  }
}
